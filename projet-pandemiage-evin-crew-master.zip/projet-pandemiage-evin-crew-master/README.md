# projet-pandemiage-evin-crew
projet-pandemiage-evin-crew created by GitHub Classroom

Corentin FANTON
Evine BUYUKKAYA
Ibrahim HADJ MESSAOUD
Ania BOUAD

commande : (avec deux IA)

java -jar target/pandemiage-1.0-SNAPSHOT-jar-with-dependencies.jar -a target/pandemiage-1.0-SNAPSHOT-ai.jar -d 0 -c ./pandemic.graphml -t 1 -s 9 -p 0 -i 2
