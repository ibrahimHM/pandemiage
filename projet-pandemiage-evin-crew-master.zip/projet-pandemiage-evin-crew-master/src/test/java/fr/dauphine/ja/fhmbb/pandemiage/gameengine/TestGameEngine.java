package fr.dauphine.ja.fhmbb.pandemiage.gameengine;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestGameEngine {

	@Test
	public void stupid() {
		assertEquals(5, 10-5);
	}

}
