package fr.dauphine.ja.fhmbb.pandemiage.gameengine;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import fr.dauphine.ja.fhmbb.pandemiage.gameset.City;

public class FileReader {
	private static List<List<String>> printNode(NodeList nl){
		List<String> s1=new ArrayList<String>();
		List<List<String>> s=new ArrayList<List<String>>();
			for(int i=0; i<nl.getLength();i++){
				Node node=nl.item(i);
				if(node.hasChildNodes()){
					if(node.hasAttributes()&&(node.getNodeName().equals("node"))){
						s1=new ArrayList<String>();s.add(s1);
						s1.add(node.getAttributes().item(0).getNodeValue());
					}
					NodeList bebe=node.getChildNodes();
					for(int j=0;j<bebe.getLength();j++){
						Node n1=bebe.item(j);
						if(n1.getChildNodes().getLength()==1){
						
						//leafNode
						s1.add(n1.getTextContent());
						
					}
				}
			}
			}
		return s;
	}
	
	private static List<List<String>> printNodeEDGE(NodeList nl){
		List<String> s1=new ArrayList<String>();
		List<List<String>> s=new ArrayList<List<String>>();
		for(int i=0; i<nl.getLength();i++){
			Node node=nl.item(i);
			if(node.hasChildNodes()){
				if(node.hasAttributes()){
					//recupere l'id sa valeur
					s1=new ArrayList<String>();
					s.add(s1);
					s1.add(node.getAttributes().item(0).getNodeValue());
					s1.add(node.getAttributes().item(1).getNodeValue());
				}
			}
		}
		return s;
}
	
	private static Map<Integer, City> getCity(NodeList lnoden,NodeList lnode){
		//List<City>
		Map<Integer, City> lc=new HashMap<Integer, City>();
		List<List<String>> lv=printNode(lnoden);
		List<List<String>> lvv=printNodeEDGE(lnode);
		
		
		for (List<String> s:lv){
			
			City c= new City(new Integer(s.get(0)), s.get(1),new Float(s.get(2)),new Integer(s.get(3)),new Float(s.get(4)),new Integer(s.get(5)),new Integer(s.get(6)),new Integer(s.get(7)),new Float(s.get(8)),new Float(s.get(9)),new ArrayList<City>());	
			lc.put(new Integer(s.get(0)), c);
			
		}
		
		//recuperer les indices des villes sources ses voisins sont les targets liées.
		List<Integer> lsource= new ArrayList<Integer>();
		List<Integer> ltarget= new ArrayList<Integer>();
		for (List<String> s:lvv){
			lsource.add(new Integer(s.get(0)));
			ltarget.add(new Integer(s.get(1)));
		}
		
		//Remplis les voisins
		for (int j=0;j<lsource.size();j++){
			City s=lc.get(lsource.get(j));
			
			City t=lc.get(ltarget.get(j));
			s.setNeighbors(t);
			t.setNeighbors(s);
			
		}
		
		return lc;
		
	}
	
	
	private static Map<String, City> GetMapCity(NodeList lnoden,NodeList lnode){
		Map<Integer,City> lc=getCity( lnoden, lnode);
		Map<String,City> map=new HashMap<String,City>();
		for(Integer i:lc.keySet()){
			map.put(lc.get(i).getCityName(), lc.get(i));
		}
		
		return map;
		
	}
	public static Map<String, City> getAllCities(){
		File f=new File("pandemic.graphml");
		DocumentBuilderFactory dbf=  DocumentBuilderFactory.newInstance();
		DocumentBuilder dbb=null;
		Document doc=null;
		Map<String,City>ms=new HashMap<String,City>();
		try {
			dbb=dbf.newDocumentBuilder();
			
			doc=dbb.parse(f);
			doc.getDocumentElement().normalize();
			//POUR NODE
			NodeList lnoden= doc.getElementsByTagName("node");
			//List<List<String>> l=printNode(lnoden);// Affichage de la matrices des villes et infos!
			//System.out.println(l);
			
			//POUR EDGE:
			NodeList lnode= doc.getElementsByTagName("edge");
			//List<List<String>> ledge=printNodeEDGE(lnode);//Affiche la matrice des voisins
			//System.out.println(ledge);
			ms=GetMapCity( lnoden, lnode);
			
		}catch (SAXException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ms; 
	}
}
