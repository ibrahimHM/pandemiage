package fr.dauphine.ja.pandemiage.common;

public enum GameStatus {
	ONGOING,
	VICTORIOUS,
	DEFEATED;
}
