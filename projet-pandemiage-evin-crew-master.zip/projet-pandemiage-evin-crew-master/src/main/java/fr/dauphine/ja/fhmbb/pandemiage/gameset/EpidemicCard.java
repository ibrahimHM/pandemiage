package fr.dauphine.ja.fhmbb.pandemiage.gameset;

import fr.dauphine.ja.pandemiage.common.Disease;

public class EpidemicCard extends PlayerCard{
	
	public EpidemicCard(String cityName, Disease disease) {
		super(cityName, disease);
		// TODO Auto-generated constructor stub
	}
	
	public EpidemicCard() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String toString() {
		return "Epidemic";
		
	}
}
