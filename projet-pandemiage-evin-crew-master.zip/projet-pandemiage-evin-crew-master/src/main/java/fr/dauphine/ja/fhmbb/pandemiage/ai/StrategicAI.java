package fr.dauphine.ja.fhmbb.pandemiage.ai;

import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import fr.dauphine.ja.pandemiage.common.AiInterface;
import fr.dauphine.ja.pandemiage.common.Disease;
import fr.dauphine.ja.pandemiage.common.GameInterface;
import fr.dauphine.ja.pandemiage.common.PlayerCardInterface;
import fr.dauphine.ja.pandemiage.common.PlayerInterface;
import fr.dauphine.ja.pandemiage.common.UnauthorizedActionException;
public class StrategicAI implements AiInterface{



	@Override
	public void playTurn(GameInterface g, PlayerInterface p) {

		Disease[] allDisease= {Disease.BLUE,Disease.YELLOW,Disease.BLACK,Disease.RED};
		int[] dominColor=new int[4];
		for(int i=0;i<dominColor.length;i++)dominColor[i]=0;
		for(PlayerCardInterface card:p.playerHand()) {
			switch (card.getDisease()) {
			case BLUE:
				dominColor[0]++;
				break;
			case YELLOW:
				dominColor[1]++;
				break;
			case BLACK:
				dominColor[2]++;
				break;
			case RED:
				dominColor[3]++;
				break;
			default:
				break;
			}
		}


		ArrayList<PlayerCardInterface> cardToKeep=new ArrayList<>();
		ArrayList<PlayerCardInterface> cardThrowable=new ArrayList<>();
		for (PlayerCardInterface card:p.playerHand())
			cardThrowable.add(card);


		//Recherche de quel carte disease on veut garder en main
		do {
			int ind=getDomiDisease(dominColor);
			Disease d=null;
			switch (ind) {
			case 0:
				d=Disease.BLUE;
				break;
			case 1:
				d=Disease.YELLOW;
				break;
			case 2:
				d=Disease.BLACK;
				break;
			case 3:
				d=Disease.RED;
				break;

			default:
				d=null;
				break;
			}

			if (d==null)//Aucune carte prioritaire
				break;
			else {
				if (g.isCured(d)) {
					//Le remède a deja ete decouvert pour cette maladie!
					dominColor[ind]=-1;
					continue;
				}else {
					for (int i=cardThrowable.size()-1;i>=0;i++) {
						PlayerCardInterface card=cardThrowable.get(i);
						if (card.getDisease()==d) {
							cardThrowable.remove(card);
							cardToKeep.add(card);
						}
					}
					break;
				}
			}
		}while (true);


		//action sur le jeu	
		for(int i=0;i<2;++i) {
			//Remede a decouvrir
			//On essaie de le crée
			if (i==0) {
				if (cardToKeep.size()==5) {
					try {
						p.discoverCure(cardToKeep);
						continue;
					}
					catch (Exception e) {
						System.out.println("Attention probleme pour cree le remède par l'IA_Strategic");
					}
				}
			}
			List<Disease> CuredDisease= new ArrayList<Disease>();
			//On recupere les remèdes crée mais pas encore eradiqué
			for(Disease d :allDisease) {
				if((g.isCured(d))&&(g.isEradicated(d)==false)){
					CuredDisease.add(d);
				}
			}//Eradiquer tout les cubes de maladie d, dont les remèdes sont découvert. Surtout les villes les plus infectés pour gagner du temps sur le jeu
			//Pour chaque malade; recupère la ville la plus contaminer et l'action lié (L'integer)

			//maladie max
			Disease dmax=null;
			int infectionMax=0;
			String Ville=null;
			int action=-1;
			List<Disease> toAnalyse;
			if (!CuredDisease.isEmpty()) {			
				toAnalyse=CuredDisease;
			}
			else {
				List<Disease> notCuredDisease= new ArrayList<Disease>();
				//On recupere les remèdes crée mais pas encore eradiqué
				for(Disease d :allDisease) {
					if((g.isCured(d)==false)&&(g.isEradicated(d)==false)){
						notCuredDisease.add(d);
					}
				}
				toAnalyse=notCuredDisease;
			}
		
			for(Disease d: toAnalyse){
				Map<Integer, String> mintermediaire=new HashMap<>();
				mintermediaire= GetActionToPlayForMovement(d,p,g,cardThrowable);

				for(Integer interAction:mintermediaire.keySet()) {
					if (g.infectionLevel(mintermediaire.get(interAction), d)>infectionMax) {
						infectionMax=g.infectionLevel(mintermediaire.get(interAction), d);
						dmax=d;
						Ville=mintermediaire.get(interAction);
						action=interAction;
					}
				}


			}

			switch (action) {
			case 0:
				
				try {
					p.treatDisease(dmax);
				} catch (UnauthorizedActionException e) {
					
					e.printStackTrace();
				}
				break;
			case 1:
				try {
					p.moveTo(Ville);
				} catch (UnauthorizedActionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					p.treatDisease(dmax);
				} catch (UnauthorizedActionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 2:
				try {
					p.flyTo(Ville);
				} catch (UnauthorizedActionException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					p.treatDisease(dmax);
				} catch (UnauthorizedActionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 3:
				try {
					p.flyToCharter(Ville);
				} catch (UnauthorizedActionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					p.treatDisease(dmax);
				} catch (UnauthorizedActionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			default:
				break;
			}



		}
		/*
			for(int i=0;i<4;++i) {
				//on test si on peut crée un remède qu'a l'entrée du tour, donc qu'une seule fois
				//1ere chose à faire
				if ((cardToKeep.size()==5)&&(i==0)){
					//on peut cree un remède de cette couleur, ne coute aucune action
					try {
						p.discoverCure(cardToKeep);
					} catch (UnauthorizedActionException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						System.out.println("Probleme de creation du remède par l'ia!\n");
					}
				}
				//Fin Decouverte Remede ou pas
				//2eme chose à faire : Eradiquer tout les cubes de maladie d, dont les remèdes sont découvert.

			}*/


	} 








	/**METHODE PRIVATE utilisées seulement dans PlayTurn par L'IA**/





	// Retourne la ville la plus touché, et donc qu'elle action choisir avec.
	// return l'indice (l'integer), pour savoir qu'elle action jouer:0=MoveTo, 1=FlyTo, 2=Charter sur quelle ville (String), pour une maladie donnée.
	private Map<Integer, String> GetActionToPlayForMovement(Disease d,PlayerInterface p,GameInterface g,ArrayList<PlayerCardInterface> cardThrowable){

		/*
			//Ind=0 represente le max lié a moveTo, 1=FlyTo, 2=Charter
			List<String> maxInfection=new ArrayList<String>();
			Map<Integer,String> lvlmax=new HashMap<Integer,String>();
			boolean flycharter=false;
			PlayerCardInterface c = null;
			//Ajout des villes
			maxInfection.add(MoveChoice(d,p,g));
			maxInfection.add(FlyToChoice(d,p,g,cardThrowable));
			for (PlayerCardInterface cd:cardThrowable){
				if(cd.getCityName().equals(p.playerLocation())){
				flycharter=true;
				c=cd;
				}
			}
			if (flycharter==true){
			// n'est rajouté que si FlyCharter est possible
			//maxInfection.add(FlyToCharterChoice(d,p,g,c));
				maxInfection.add(c.getCityName());
			}
			for(String city:maxInfection){
				lvlmax.put(g.infectionLevel(city, d),city);
			}
			//recupere le max entre les trois actions et la ville liée.
			int max=0;
			for(Integer i:lvlmax.keySet()){
				if (i>max){
					max=i;	
				}
			}
			//Collections.sort(lvlmax);
			//Collections.reverse(lvlmax);
			//return la plus grande infection pour cette maladie
			return lvlmax.get(max);
		 */

		// return l'indice, pour savoir qu'elle action jouer:0=Rester a la ville,1=MoveTo, 2=FlyTo, 3=Charter
		Map<Integer,String> ActionsVille= new HashMap<Integer,String>();
		ActionsVille.put(g.infectionLevel(p.playerLocation(), d),p.playerLocation());

		int ind=-1;
		int maxInfectionRate=0;
		boolean flycharter=false;
		PlayerCardInterface c = null;
		//Ajout des villes
		ActionsVille.put(g.infectionLevel(MoveChoice(d,p,g),d),MoveChoice(d,p,g));
		ActionsVille.put(g.infectionLevel(FlyToChoice(d,p,g,cardThrowable),d),FlyToChoice(d,p,g,cardThrowable));
		for (PlayerCardInterface cd:cardThrowable){
			if(cd.getCityName().equals(p.playerLocation())){
				flycharter=true;
				c=cd;
			}
		}
		if (flycharter==true){
			// n'est rajouté que si FlyCharter est possible
			//maxInfection.add(FlyToCharterChoice(d,p,g,c));
			ActionsVille.put(g.infectionLevel(c.getCityName(),d),c.getCityName());
		}
		int cpt=0;
		for(Integer i:ActionsVille.keySet()){
			if (i>maxInfectionRate){
				maxInfectionRate=i;	
				ind=cpt;
			}
			cpt++;
		}


		Map<Integer,String> returnvalue= new HashMap<Integer,String>();
		returnvalue.put(ind, ActionsVille.get(maxInfectionRate));
		return returnvalue;
	}

	/**
	 * Representera les villes voisines et leur niveau d'infection: Pour l'action MoveTo()
	 * @param d 
	 * @param p
	 * @param g
	 * @return la ville la plus affecter atteintgnable par moveTo()
	 * 
	 */
	private String MoveChoice(Disease d,PlayerInterface p,GameInterface g){
		//Representera les villes voisines et leur niveau d'infection:
		Map<Integer,String> l=new HashMap<Integer,String>();
		String  PlayerCityString=p.playerLocation();
		List<String> Neighbours=g.neighbours(PlayerCityString);
		//List<City> CityNeighbours=new ArrayList<City>();
		for (String c:Neighbours){
			l.put(g.infectionLevel(c, d),c);
		}
		String maxInfectionlvl=max(l,g,d);
		//MoveTo : recuperons la ville avec le max niveau  d'infection parmis les voisins,
		return maxInfectionlvl;

	}

	/**
	 * @param l
	 * @param g
	 * @param d
	 * @return
	 */
	private String max( Map<Integer,String> l,GameInterface g,Disease d){
		//taux d'infection ville de départ
		int max=0;
		for (Integer i:l.keySet()){
			if(i>max){
				max=i;
			}
		}
		//return la ville la plus infectée
		return l.get(max);

	}
	private String FlyToChoice(Disease d,PlayerInterface p,GameInterface g,ArrayList<PlayerCardInterface> cardThrowable){
		//recuperer le niveau d'infection des villes ou je peux flyTo sans compter les cartes que l'on garde pour trouver un remède
		Map<Integer,String> l=new HashMap<Integer,String>();
		for (PlayerCardInterface c:cardThrowable){
			String s=c.getCityName();
			if (!s.equals(p.playerLocation())){
				l.put(g.infectionLevel(s, d),s);				
			}
		}
		String maxInfectionlvl=max( l,g,d);
		//return la ville la plus infectée parmi celle ou je peux voyager!
		return maxInfectionlvl;
	}
	/*
		private Map<Integer,String> FlyToCharterChoice(Disease d,PlayerInterface p,GameInterface g, PlayerCardInterface cardThrowable){
			//Recuperer niveau d'infection de la ville FlyToCharter si l'action est possible 
			//int maxInfectionlvl=0;
			List<Integer> l=new ArrayList<Integer>();
			for (PlayerCardInterface c: cardThrowable){
				l.add(g.infectionLevel(c.getCityName(), d));

			}
			return  {g.infectionLevel(cardThrowable.getCityName(),d),cardThrowable.getCityName()};
		}*/
	private int getDomiDisease(int[] dominColor) {
		int max=-1;
		for(int i=0;i<dominColor.length;i++)
			if(max==-1 || dominColor[max]>dominColor[i])
				max=i;

		return max;
	}





	// a completer!
	@Override
	public List<PlayerCardInterface> discard(GameInterface g, PlayerInterface p, int maxHandSize, int nbEpidemic){

		Disease[] allDisease= {Disease.BLUE,Disease.YELLOW,Disease.BLACK,Disease.RED};
		int[] dominColor=new int[4];
		for(int i=0;i<dominColor.length;i++)dominColor[i]=0;
		for(PlayerCardInterface card:p.playerHand()) {
			switch (card.getDisease()) {
			case BLUE:
				dominColor[0]++;
				break;
			case YELLOW:
				dominColor[1]++;
				break;
			case BLACK:
				dominColor[2]++;
				break;
			case RED:
				dominColor[3]++;
				break;
			default:
				break;
			}
		}


		ArrayList<PlayerCardInterface> cardToKeep=new ArrayList<>();
		ArrayList<PlayerCardInterface> cardThrowable=new ArrayList<>();
		for (PlayerCardInterface card:p.playerHand())
			cardThrowable.add(card);


		//Recherche de quel carte disease on veut garder en main
		do {
			int ind=getDomiDisease(dominColor);
			Disease d=null;
			switch (ind) {
			case 0:
				d=Disease.BLUE;
				break;
			case 1:
				d=Disease.YELLOW;
				break;
			case 2:
				d=Disease.BLACK;
				break;
			case 3:
				d=Disease.RED;
				break;

			default:
				d=null;
				break;
			}

			if (d==null)//Aucune carte prioritaire
				break;
			else {
				if (g.isCured(d)) {
					//Le remède a deja ete decouvert pour cette maladie!
					dominColor[ind]=-1;
					continue;
				}else {
					for (int i=cardThrowable.size()-1;i>=0;i++) {
						PlayerCardInterface card=cardThrowable.get(i);
						if (card.getDisease()==d) {
							cardThrowable.remove(card);
							cardToKeep.add(card);
						}
					}
					break;
				}
			}
		}while (true);

		Random r=new Random();
		ArrayList<PlayerCardInterface> discard=new ArrayList<>();
		for(int i=0;i<p.playerHand().size()-maxHandSize;i++) {
			if (cardThrowable.size()>0) {
				discard.add(cardThrowable.remove(r.nextInt(cardThrowable.size())));
			}else {
				discard.add(cardToKeep.remove(r.nextInt(cardThrowable.size())) );
			}
		}
		return discard;
		//		List<PlayerCardInterface> discard = new ArrayList<>();
		//		int numdiscard = p.playerHand().size() - maxHandSize;  
		//
		//		for(int i = 0; i < numdiscard; i++)
		//			discard.add(p.playerHand().get(i)); 

	}
}

