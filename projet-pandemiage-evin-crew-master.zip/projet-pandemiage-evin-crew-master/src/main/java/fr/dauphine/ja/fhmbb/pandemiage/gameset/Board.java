package fr.dauphine.ja.fhmbb.pandemiage.gameset;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import fr.dauphine.ja.fhmbb.pandemiage.gameengine.FileReader;
import fr.dauphine.ja.fhmbb.pandemiage.gameengine.GameEngine;
import fr.dauphine.ja.pandemiage.common.Disease;

public class Board {
	//Gameengine
	private GameEngine g;
	//Cities
	private Map<String,City> allCities;
	//Decks
	private Deck<PlayerCard> playerCardDeck;
	private Deck<InfectionCard> infectionCardDeck;
	private Deck<PlayerCard> discardedPlayerCardDeck;
	private Deck<InfectionCard> discardedInfectionCardDeck;
	//Block stock
	private BlockStock redBlocks;
	private BlockStock yellowBlocks;
	private BlockStock blueBlocks;
	private BlockStock blackBlocks;
	private int outBreakCounter;
	//Markers
	private Map<Disease,Boolean> cureMarker;
	private Map<Disease,Boolean> isEradicated;
	private int infectionRate;
	private int nbDiscover;

	private int currentPlayer;
	
	private static final int NB_CARDS_BY_PLAYERS = 5;
	private static final int NB_BLOCK_INITIALIZATION = 24;

	public Board() {
		
		this.outBreakCounter = 0;
		this.yellowBlocks = new BlockStock();
		this.redBlocks = new BlockStock();
		this.blueBlocks = new BlockStock();
		this.blackBlocks = new BlockStock();
		this.yellowBlocks.add(NB_BLOCK_INITIALIZATION, new Block(Disease.YELLOW));
		this.redBlocks.add(NB_BLOCK_INITIALIZATION, new Block(Disease.RED));
		this.blueBlocks.add(NB_BLOCK_INITIALIZATION, new Block(Disease.BLUE));
		this.blackBlocks.add(NB_BLOCK_INITIALIZATION, new Block(Disease.BLACK));	
		this.currentPlayer = 0;
		
		
		
		this.allCities = new HashMap<String,City>();
		this.allCities = FileReader.getAllCities();
		
		this.cureMarker = new HashMap<Disease, Boolean>();

		
		this.isEradicated = new HashMap<Disease, Boolean>();
		
		this.playerCardDeck = new Deck<PlayerCard>();
		this.infectionCardDeck = new Deck<InfectionCard>();
		this.discardedPlayerCardDeck = new Deck<PlayerCard>();
		this.discardedInfectionCardDeck = new Deck<InfectionCard>();
		
	}

	
	public void initialization() {
		
			
			for (Disease d : Disease.values()) {
				putCureMarker(d,false);
			}
		
			for (Disease d : Disease.values()) {
				  this.isEradicated.put(d, false);
			}
			
			// Make infection and player card deck
			for (Map.Entry<String, City> entry : allCities.entrySet()) {
				City city = entry.getValue();
				playerCardDeck.addToTop(new PlayerCard(city.getCityName(),city.getDisease()));
				infectionCardDeck.addToTop(new InfectionCard(city.getCityName(),city.getDisease()));
			}
			
			
			// shuffle playerCard deck
			this.playerCardDeck.Shuffle();

			// Distribute player cards to players
			try {
				for(int i=0;i<NB_CARDS_BY_PLAYERS;i++) {
					for(int j=0;j<g.getNbPlayers();j++) {
						g.getPlayers().get(j).addCardToHand(this.playerCardDeck.pickCard());
						
					}
				}
				
			} catch(java.util.NoSuchElementException e) {
				System.out.println("Deck is empty ! complete the deck before intialize hand : " + e.getMessage());
			}
			
			// insert epidemic card into player card deck	
			insertEpidemicCard(g.getDifficulty());
			
			// Shuffle infection card deck
			this.infectionCardDeck.Shuffle();
			
			// infect first cities
			for(int i=0;i<9;i++) {
				InfectionCard icard = this.infectionCardDeck.pickCard();
				if(i<3) {
					g.infect(icard.getCityName(), icard.getDisease(), 3);
					
				} else if(i>2 && i<6) {
					g.infect(icard.getCityName(), icard.getDisease(), 2);
					
				} else {
					g.infect(icard.getCityName(), icard.getDisease(), 1);
					
				}
				//System.out.println(i + " : " + icard.getCityName() + " - " + icard.getDisease() + " : " + infectionLevel(icard.getCityName(),icard.getDisease()) );
				
			}
			
			//System.out.println("redBlocks : " + this.redBlocks.size());System.out.println("yellowBlocks : " + this.yellowBlocks.size());System.out.println("blackBlocks : " + this.blackBlocks.size());System.out.println("blueBlocks : " + this.blueBlocks.size());

			
			
			
			
	}

	
		


	public GameEngine getG() {
		return g;
	}


	public Map<String, City> getAllCities() {
		return allCities;
	}



	public Deck<PlayerCard> getPlayerCardDeck() {
		return playerCardDeck;
	}



	public Deck<InfectionCard> getInfectionCardDeck() {
		return infectionCardDeck;
	}



	public Deck<PlayerCard> getDiscardedPlayerCardDeck() {
		return discardedPlayerCardDeck;
	}



	public Deck<InfectionCard> getDiscardedInfectionCardDeck() {
		return discardedInfectionCardDeck;
	}



	public BlockStock getRedBlocks() {
		return redBlocks;
	}



	public BlockStock getYellowBlocks() {
		return yellowBlocks;
	}



	public BlockStock getBlueBlocks() {
		return blueBlocks;
	}



	public BlockStock getBlackBlocks() {
		return blackBlocks;
	}



	public int getOutBreakCounter() {
		return outBreakCounter;
	}



	public Map<Disease, Boolean> getCureMarker() {
		return cureMarker;
	}



	public Map<Disease, Boolean> getIsEradicated() {
		return isEradicated;
	}


	public int getInfectionRate() {
		return infectionRate;
	}
	
	public void setInfectionRate(int infectionRate) {
		this.infectionRate = infectionRate;
	}
	
	public void setOutBreakCounter(int outBreakCounter) {
		this.outBreakCounter = outBreakCounter;
	}
	public void setCureMarker(Map<Disease, Boolean> cureMarker) {
		this.cureMarker = cureMarker;
	}

	public void setCureMarker(Disease d, Boolean bool) {
		this.cureMarker.replace(d,bool);
		for (Map.Entry<Disease, Boolean> entry : cureMarker.entrySet()) {
			if(entry.getValue()) {
				setNbDiscover(getNbDiscover() + 1);
			}
		}
		
	}
	
	public void putCureMarker(Disease d, Boolean bool) {
		this.cureMarker.put(d,bool);
		
	}
	
	public void setIsEradicated(Disease d, Boolean bool) {
		this.isEradicated.replace(d,bool);
	}



	public int getCurrentPlayerId() {
		return currentPlayer;
	}



	public void setCurrentPlayer(int currentPlayer) {
		this.currentPlayer = currentPlayer;
	}
	
	public void setG(GameEngine g) {
		this.g = g;
	}
	
	public City getCityByName(String cityName) {
		return this.allCities.get(cityName);
	}
	
	public void addToStock(Disease d) {
		//System.out.println("STOCK : " + "Blue : " + this.blueBlocks.size() + " -  Yellow : " + this.yellowBlocks.size() + " -  Black : " + this.blackBlocks.size() + "  -  Red : " + this.redBlocks.size());

		switch(d) {
		case RED:
			this.redBlocks.add(new Block(d));
			break;
		case YELLOW:
			this.yellowBlocks.add(new Block(d));
			break;
		case BLACK:
			this.blackBlocks.add(new Block(d));
			break;
		default:
			this.blueBlocks.add(new Block(d));
			break;
		}
		//System.out.println("STOCK : " + "Blue : " + this.blueBlocks.size() + " -  Yellow : " + this.yellowBlocks.size() + " -  Black : " + this.blackBlocks.size() + "  -  Red : " + this.redBlocks.size());

	}
	
	/**
	 * Insert into player deck, 4, 5, or 6 Epidemic cards uniformly for an Introductory, Standard, or Heroic game.
	 * @param difficulty
	 */
	public void insertEpidemicCard(int difficulty) {
		 int nbDeck =0;
		 switch (difficulty) {
		 case 0:  nbDeck = 4;
		          break;
		 case 1:  nbDeck = 5;
		          break;
		 case 2:  nbDeck = 6;
		 		  break;
		 }
		 
		 int splitDeck = this.playerCardDeck.size()/nbDeck;
			int cpt = 0;
			for(int i=0;i<playerCardDeck.size();i++) {
				if(i%splitDeck == 0) {
					int endSplit = i + splitDeck-1;
					if(cpt == nbDeck-1) {
						endSplit = playerCardDeck.size()-1;
					}
					
					cpt++;
					
					Random rd = new Random();
					int randomPos = rd.nextInt((endSplit - i) + 1) + i; // index of the position of the epidemic card
					playerCardDeck.insertCard(randomPos, new EpidemicCard());
				}
				if(cpt == nbDeck) {
					break;
				}
			}
	}
	
	public void getPlayers() {
		g.getPlayers();
	}


	public int getNbDiscover() {
		return nbDiscover;
	}


	public void setNbDiscover(int nbDiscover) {
		this.nbDiscover = nbDiscover;
	}
	
}
