package fr.dauphine.ja.fhmbb.pandemiage.ui;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import fr.dauphine.ja.fhmbb.pandemiage.gameengine.GameEngine;
import fr.dauphine.ja.fhmbb.pandemiage.gameset.Board;

public class Cli {
	public static final String DEFAULT_AIJAR = "./target/pandemiage-1.0-SNAPSHOT-ai.jar"; 
	public static final String DEFAULT_CITYGRAPH_FILE = "./pandemic.graphml";
	public static final int DEFAULT_TURN_DURATION = 1;	//in seconds
	public static final int DEFAULT_DIFFICULTY = 0; // easy
	public static final int DEFAULT_HAND_SIZE = 9;
	public static final int NUMBER_OF_PLAYERS = 0; // number of human players
	public static final int NUMBER_OF_IAPLAYERS = 1;
	 
	
	public static void main(String[] args) {
		//java -jar target/pandemiage-1.0-SNAPSHOT-jar-with-dependencies.jar -a target/pandemiage-1.0-SNAPSHOT-ai.jar -d 0 -c ./pandemic.graphml -t 1 -s 9 -p 0 -i 2
		String aijar = DEFAULT_AIJAR; 
		String cityGraphFile = DEFAULT_CITYGRAPH_FILE; 
		int difficulty = DEFAULT_DIFFICULTY; 
		int turnDuration = DEFAULT_TURN_DURATION;
		int handSize = DEFAULT_HAND_SIZE;
		int nbPlayers = NUMBER_OF_PLAYERS;
		int nbIAPlayers = NUMBER_OF_IAPLAYERS;
		
		Options options = new Options();
		CommandLineParser parser = new DefaultParser();

		options.addOption("a", "aijar", true, "use <FILE> as player Ai.");
		options.addOption("d", "difficulty", true, "Difficulty level. 0 (Introduction), 1 (Normal) or 3 (Heroic).");
		options.addOption("c", "citygraph", true, "City graph filename.");
		options.addOption("t", "turnduration", true, "Number of seconds allowed to play a turn.");
		options.addOption("s", "handsize", true, "Maximum size of a player hand.");
		options.addOption("p", "human", true, "Number of human players");
		options.addOption("i", "ai", true, "Number of ai players");
		options.addOption("h", "help", false, "Display this help");
		options.addOption("g", "gui", false, "Display the GUI");
		
		
		try {
			CommandLine cmd = parser.parse( options, args);
			
			if(cmd.hasOption("a")) {
				
				aijar = cmd.getOptionValue("a");				
			}
			
			if(cmd.hasOption("c")) {
				cityGraphFile = cmd.getOptionValue("c");
			}

			if(cmd.hasOption("d")) {
		
				difficulty = Integer.parseInt(cmd.getOptionValue("d"));
			}
			
			if(cmd.hasOption("t")) {
				
				turnDuration = Integer.parseInt(cmd.getOptionValue("t"));
			}
			if(cmd.hasOption("s")) {

				handSize = Integer.parseInt(cmd.getOptionValue("s"));
			}
			
			if(cmd.hasOption("p")) {
			
				nbPlayers = Integer.parseInt(cmd.getOptionValue("p"));
			}
			
			if(cmd.hasOption("i")) {
	
				nbIAPlayers = Integer.parseInt(cmd.getOptionValue("i"));
			}
			
			if(cmd.hasOption("g")) {
				Gui.main(args);
			}

			/* ... */ 
			
			if(cmd.hasOption("h")) {
				HelpFormatter formatter = new HelpFormatter();
				formatter.printHelp( "pandemiage", options );
				System.exit(0);
			}			
			
		} catch (ParseException e) {
			System.err.println("Error: invalid command line format.");
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp( "pandemiage", options );
			System.exit(1);
	    }
		
		Board b = new Board();
		GameEngine g = new GameEngine(cityGraphFile, aijar, handSize, difficulty,turnDuration, nbPlayers,nbIAPlayers, b);
		b.setG(g);

		g.loop();		
	}
}
