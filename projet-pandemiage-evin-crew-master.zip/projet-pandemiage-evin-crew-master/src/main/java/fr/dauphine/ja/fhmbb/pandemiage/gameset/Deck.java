package fr.dauphine.ja.fhmbb.pandemiage.gameset;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;

public class Deck<T extends Card> implements Iterable<T> {
	
	private LinkedList<T> deck;
	
	public Deck() {
        deck = new LinkedList<T>();
    }
	
	public void addToTop(T card) {
        deck.addFirst(card);
    }
	
	public void Shuffle() {
		Collections.shuffle(deck);
	}
	
	public T pickCard() {
		return deck.pollFirst();
		
	}
	
	public T pickCardFromBottom() {
		return deck.pollLast();
	}
	
	@Override
	public Iterator<T> iterator() {
		// TODO Auto-generated method stub
		return this.deck.iterator();
	}

	public int size() {
		// TODO Auto-generated method stub
		return deck.size();
	}
	
	public void insertCard(int index, T card) {
		 deck.add(index, card);
	}
}
