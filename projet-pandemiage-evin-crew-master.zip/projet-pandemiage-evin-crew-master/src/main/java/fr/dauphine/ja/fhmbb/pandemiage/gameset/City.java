package fr.dauphine.ja.fhmbb.pandemiage.gameset;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import fr.dauphine.ja.pandemiage.common.Disease;

public class City {
	private String cityName;
	private HashMap<Disease, Integer> infectionLevel;
	private float eigencentrality;
	private int id;
	private int r;
	private int g;
	private int b;
	private float x;
	private float y;
	private float size;
	private int degree;
	private boolean outBreakDetected;
	private List<City> neighbors;
	
	public City(int id, String cityName, float eigencentrality, int d,float s, int r, int g, int b, float x, float y,List<City> n) {
		super();
		this.cityName = cityName;
		this.eigencentrality = eigencentrality;
		this.degree=d;
		this.size=s;
		this.r = r;
		this.g = g;
		this.b = b;
		this.x = x;
		this.y = y;
		this.id=id;
		this.outBreakDetected = false;
		this.neighbors = new ArrayList<City>();
		this.neighbors.addAll(n);
		this.infectionLevel = new HashMap<Disease, Integer>();
		for(Disease dis : Disease.values()) {
			infectionLevel.put(dis, 0);
		}

	}


	@Override
	public String toString() {
		//return "City [cityName=" + cityName + ", infectionLevel=" + infectionLevel + ", neighbors=" + neighbors + "]";
		return  cityName + " : " + infectionLevel;
	}


	public Disease getDisease() {
		if((this.r == 107) && (this.g == 112) && (this.b==184)) {
			return Disease.BLUE;
		} else if ((this.r == 153) && (this.g == 153) && (this.b==153)) {
			return Disease.BLACK;
		}else if ((this.r == 153) && (this.g == 18) && (this.b==21)) {
			return Disease.RED;
		}else if ((this.r == 242) && (this.g == 255) && (this.b==0)) {
			return Disease.YELLOW;
		} else {
			return null;
		}
		
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public float getEigencentrality() {
		return eigencentrality;
	}

	public void setEigencentrality(float eigencentrality) {
		this.eigencentrality = eigencentrality;
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}

	public int getG() {
		return g;
	}

	public void setG(int g) {
		this.g = g;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	public int getInfectionLevel(Disease d) {
		return infectionLevel.get(d);
	}
	
	public void setInfectionLevel(Disease d, int infection) {
		infectionLevel.put(d,infection);
	}
	
	public void infect(Disease d, int nbBlocks) {	
		this.infectionLevel.put(d, infectionLevel.get(d) + nbBlocks);
	}
	
	public void setNeighbors(City c){
		neighbors.add(c);
		/*
		List<City> v=new ArrayList<City>();
		for(City ci:c){
			v.add(ci.copy());
		}
		neighbors=v;*/
	}
	
	public List<City> getNeighbors() {
		return neighbors;
	}


	public boolean isOutBreakDetected() {
		return outBreakDetected;
	}


	public void setOutBreakDetected(boolean outBreakDetected) {
		this.outBreakDetected = outBreakDetected;
	}
	
	
	
}
