package fr.dauphine.ja.fhmbb.pandemiage.gameset;

import fr.dauphine.ja.pandemiage.common.Disease;

public class Block {
	Disease disease;
	
	public Block(Disease disease) {
		this.disease = disease;
	}
}
