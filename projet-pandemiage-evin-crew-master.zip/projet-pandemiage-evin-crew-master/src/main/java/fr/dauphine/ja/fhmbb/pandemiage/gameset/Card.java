package fr.dauphine.ja.fhmbb.pandemiage.gameset;

public abstract class Card {

}
