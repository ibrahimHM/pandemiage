package fr.dauphine.ja.fhmbb.pandemiage.gameengine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import fr.dauphine.ja.fhmbb.pandemiage.gameset.Board;
import fr.dauphine.ja.fhmbb.pandemiage.gameset.City;
import fr.dauphine.ja.fhmbb.pandemiage.gameset.EpidemicCard;
import fr.dauphine.ja.fhmbb.pandemiage.gameset.InfectionCard;
import fr.dauphine.ja.fhmbb.pandemiage.gameset.Player;
import fr.dauphine.ja.fhmbb.pandemiage.gameset.PlayerCard;
import fr.dauphine.ja.fhmbb.pandemiage.human.HumanPlayer;
import fr.dauphine.ja.pandemiage.common.AiInterface;
import fr.dauphine.ja.pandemiage.common.AiLoader;
import fr.dauphine.ja.pandemiage.common.DefeatReason;
import fr.dauphine.ja.pandemiage.common.Disease;
import fr.dauphine.ja.pandemiage.common.GameInterface;
import fr.dauphine.ja.pandemiage.common.GameStatus;
import fr.dauphine.ja.pandemiage.common.PlayerCardInterface;

/**
 * Empty GameEngine implementing GameInterface
 *
 */
public class GameEngine implements GameInterface{

	private final String aiJar;
	@SuppressWarnings("unused")
	private final String cityGraphFilename; 	
	private GameStatus gameStatus;
	private int maxHandSize;
	private int difficulty;
	@SuppressWarnings("unused")
	private int nbHumanPlayers;
	@SuppressWarnings("unused")
	private int nbIAPlayers;
	private int nbEpidemicCards;
	private int turnDuration;
	private Board b;
	// Players
	private List<Player> players;

	private final int MAX_NUMBER_OUTBREAK = 8;
	
	// Do not change!
	private void setDefeated(String msg, DefeatReason dr) {		
		gameStatus = GameStatus.DEFEATED;
		System.err.println("Player(s) have been defeated: " + msg);
		System.err.println("Result: " + gameStatus);
		System.err.println("Reason: " + dr);
		printGameStats();
		System.exit(2);
	}

	// Do not change!
	private void setVictorious() {
		gameStatus = GameStatus.VICTORIOUS;
		System.err.println("Player(s) have won.");
		System.err.println("Result: " + gameStatus);
		printGameStats();
		System.exit(0);
	}

	// Do not change!
	private void printGameStats() {
		Map<Disease, Integer> blocks = new HashMap<>();
		for(String city : allCityNames()) {
			for(Disease d : Disease.values()) {
				blocks.put(d, blocks.getOrDefault(city, 0) + infectionLevel(city, d));
			}
		}
		System.err.println(blocks);
		System.err.println("Infection-rate:"+infectionRate());
		for(Disease d : Disease.values()) {
			System.err.println("Cured-" + d + ":"+isCured(d));
		}
		System.err.println("Nb-outbreaks:"+getNbOutbreaks());
		System.err.println("Nb-player-cards-left:"+getNbPlayerCardsLeft());

	}

	public GameEngine(String cityGraphFilename, String aiJar, int maxHandSize, int difficulty,int turnDuration, int nbHumanPlayers, int nbIAPlayers, Board b){
		this.cityGraphFilename = cityGraphFilename; 
		this.aiJar = aiJar; 
		this.gameStatus = GameStatus.ONGOING;
		this.maxHandSize = maxHandSize;
		this.difficulty = difficulty;
		this.turnDuration = turnDuration;
		this.nbHumanPlayers = nbHumanPlayers;
		this.nbIAPlayers = nbIAPlayers;
		this.b = b;
		this.players = new ArrayList<Player>();
	
		
		for(int i=0;i<nbHumanPlayers;i++) {
			this.players.add(new Player("Human-"+i, b, false));
		}
		
		for(int i=0;i<nbIAPlayers;i++) {
			this.players.add(new Player("playerAI-"+i, b, true));
		}

	}
	

	/**
	 * Call the method initialization from Board.
	 * load ai
	 * do 4 actions
	 * Play infection
	 * pick two card. If epidemic : play epidemic
	 * Discard card if hand > 9
	 * 
	 */
	public void loop()  {
		b.initialization();
		// Load Ai from Jar file
		System.out.println("Loading AI Jar file " + aiJar);		
		AiInterface ai = AiLoader.loadAi(aiJar);
		HumanPlayer hp = new HumanPlayer();
		
		// Very basic game loop
		while(gameStatus == GameStatus.ONGOING) {
			System.out.println("STOCK : " + "Blue : " + b.getBlueBlocks().size() + " -  Yellow : " + b.getYellowBlocks().size() + " -  Black : " + b.getBlackBlocks().size() + "  -  Red : " + b.getRedBlocks().size());
			System.out.println("Now " + players.get(b.getCurrentPlayerId()) + " is Playing. Location : " + players.get(b.getCurrentPlayerId()).playerLocation());
			long startTime = System.currentTimeMillis();
			
			if(players.get(b.getCurrentPlayerId()).isAi()) {
			// AI play 4 actions
				ai.playTurn(this, players.get(b.getCurrentPlayerId()));
			} else {
				hp.playTurn(this, players.get(b.getCurrentPlayerId()));
				
			}
			this.turnDuration = (int)((System.currentTimeMillis() - startTime)/1000);
			if(b.getNbDiscover()>3) {
				setVictorious();
			}
			
			// Pick two players cards
			for(int i=0;i<2;i++) {	
				nbEpidemicCards=0;
				PlayerCard pickedCard = b.getPlayerCardDeck().pickCard();
				if(pickedCard instanceof EpidemicCard) {
					nbEpidemicCards++;
					b.getDiscardedPlayerCardDeck().addToTop(pickedCard);
					playEpidemic();
				} else if(pickedCard == null){
					System.out.println("Player card deck is empty !");
					setDefeated("YOU LOSE", DefeatReason.NO_MORE_PLAYER_CARDS);
				} else {
					players.get(b.getCurrentPlayerId()).addCardToHand(pickedCard);
				}
		
			}
			
			playInfection();
			
			if(players.get(b.getCurrentPlayerId()).handSize() > maxHandSize) {
				List<PlayerCardInterface> discard = new ArrayList<PlayerCardInterface>();
				if(players.get(b.getCurrentPlayerId()).isAi() == true) {
					discard = ai.discard(this, players.get(b.getCurrentPlayerId()), this.maxHandSize, nbEpidemicCards);
					
					
				} else {
					discard = hp.discard(this, players.get(b.getCurrentPlayerId()), this.maxHandSize, nbEpidemicCards);
				}
				
				for(PlayerCardInterface c : discard) {
					players.get(b.getCurrentPlayerId()).discardCardFromHand((PlayerCard) c);
					b.getDiscardedPlayerCardDeck().addToTop((PlayerCard) c);
				}
			}
				
			// Next player
			if(b.getCurrentPlayerId() == this.players.size()-1) {
				b.setCurrentPlayer(0);
			}else {
				b.setCurrentPlayer(b.getCurrentPlayerId()+1);
			}
			
		
		}
		
		
		
	}
	
	/**
	 * Play epidemic. Call when the player pick epidemic car
	 */
	public void playEpidemic() {
		System.out.println("******* EPIDEMIC ! *******");
		b.setInfectionRate(b.getInfectionRate()+1); //Increase
		InfectionCard infectionCard = b.getInfectionCardDeck().pickCardFromBottom();
		String cityName = infectionCard.getCityName();
		Disease disease = infectionCard.getDisease();

		if(getNbBlocks(disease)<3) { // if no more blocks
			setDefeated("YOU LOSE", DefeatReason.NO_MORE_BLOCKS);
		}
		int blocks = 3 - infectionLevel(cityName, disease);
		
		if(blocks<3) {
			infect(cityName,disease,blocks);
			outBreak(cityName,disease);
		} else {
			infect(cityName,disease,blocks);
		}
		
		
	
		b.getDiscardedInfectionCardDeck().addToTop(infectionCard);
		//Intensify
		b.getDiscardedInfectionCardDeck().Shuffle();
		for(InfectionCard c : b.getDiscardedInfectionCardDeck())
			b.getInfectionCardDeck().addToTop(c);
		
	}
	
	/**
	 * Play infection
	 */
	public void playInfection() {
		for(int i=0;i<b.getInfectionRate();i++) {
			InfectionCard icard = b.getInfectionCardDeck().pickCard();
			String cityName = icard.getCityName();
			Disease d = icard.getDisease();
			if(!isEradicated(d)){
				if(infectionLevel(cityName, d)>2) {
					outBreak(cityName, d);
				} else {
					infect(cityName,d,1);
				}
			}
			b.getDiscardedInfectionCardDeck().addToTop(icard);
		}
		
	}
	
	/**
	 * 
	 * @param cityName
	 * @param d
	 */
	public void outBreak(String cityName, Disease d) {
		System.out.println("******* OUTBREAK ! *******");
		City c = b.getAllCities().get(cityName);

		c.setOutBreakDetected(true);
		b.setOutBreakCounter(b.getOutBreakCounter()+1);
		if(b.getOutBreakCounter() == MAX_NUMBER_OUTBREAK)
			setDefeated("YOU LOSE", DefeatReason.TOO_MANY_OUTBREAKS);
		
		for(String neighbor : neighbours(cityName)) {
			if(infectionLevel(neighbor,d)>2) {
				City n = b.getAllCities().get(neighbor);
				if(!n.isOutBreakDetected()) {
					outBreak(neighbor,d);
				}
			} else {
				infect(neighbor,d,1);
			}
		}
	}
	
	/**
	 * 
	 * @param cityName
	 * @param d
	 * @param nbBlocks
	 */
	public void infect(String cityName, Disease d, int nbBlocks) {
		
		switch(d) {
		case RED:
			b.getRedBlocks().remove(nbBlocks);
			break;
		case YELLOW:
			b.getYellowBlocks().remove(nbBlocks);;
			break;
		case BLACK:
			b.getBlackBlocks().remove(nbBlocks);;
			break;
		default:
			b.getBlueBlocks().remove(nbBlocks);;
			break;
		}
		
		
		b.getAllCities().get(cityName).infect(d, nbBlocks);
	}
	
	public int getNbBlocks(Disease d) {
		switch(d) {
		case RED:
			return b.getRedBlocks().size();
		case YELLOW:
			return b.getYellowBlocks().size();
		case BLACK:
			return b.getBlackBlocks().size();
		default:
			return b.getBlueBlocks().size();
		}
	}
	
	
	


	@Override
	public List<String> allCityNames() {
		// TODO
		List<String> allCityNames = new ArrayList<String>();
		for (Map.Entry<String, City> entry : b.getAllCities().entrySet()) {
			City city = entry.getValue();
			allCityNames.add(city.getCityName());
			
		}
		
		return allCityNames;
	}

	@Override
	public List<String> neighbours(String cityName) {
		List<String> neighboursName = new ArrayList<String>();
		List<City> neighbours = new ArrayList<City>();
		neighbours = b.getAllCities().get(cityName).getNeighbors();
		
		for(City neighbor : neighbours) {
			neighboursName.add(neighbor.getCityName());
		}
		
		return neighboursName;
	}

	@Override
	public int infectionLevel(String cityName, Disease d) {;
		return b.getAllCities().get(cityName).getInfectionLevel(d);
		
	}

	@Override
	public boolean isCured(Disease d) {
		return b.getCureMarker().get(d); 
	}
	
	public void cure(Disease d) {
		b.setCureMarker(d, true);
	}

	@Override
	public int infectionRate() {
		switch(b.getInfectionRate()){
	        case 0:
	            return 2;
	        case 1:
	            return 2;
	        case 2:
	            return 2;
	        case 3:
	            return 3;
	        case 4:
	            return 3;
	        default:
	            return 4;
		}
	}

	@Override
	public GameStatus gameStatus() {
		return this.gameStatus;
	}

	@Override 
	public int turnDuration() {
		// TODO
		return this.turnDuration;
	}

	@Override
	public boolean isEradicated(Disease d) {
		int blocksInGame=0;
		for(String c : allCityNames()) {
			blocksInGame += infectionLevel(c,d);
		}
		if(isCured(d) && blocksInGame==0) {
			b.setIsEradicated(d, true);
		} 
		
		return b.getIsEradicated().get(d);
	}

	@Override
	public int getNbOutbreaks() {
		return b.getOutBreakCounter();
	}

	@Override
	public int getNbPlayerCardsLeft() {
		return b.getPlayerCardDeck().size();
	}

	@Override
	public List<String> getDiscardedInfectionCards() {
		List<String> discardedInfectionCards = new ArrayList<String>();
		for(InfectionCard card : b.getDiscardedInfectionCardDeck()) {
			discardedInfectionCards.add(card.getCityName());
		}
		return discardedInfectionCards;
	}
	
	
	public int getNbPlayers() {
		return players.size();
	}

	public List<Player> getPlayers() {
		return players;
	}

	public void setPlayers(List<Player> players) {
		this.players = players;
	}
	
	public int getDifficulty() {
		return difficulty;
	}

	
}
