package fr.dauphine.ja.fhmbb.pandemiage.gameset;

import java.util.LinkedList;

public class BlockStock {
	
	private LinkedList<Block> stock;
	
	public BlockStock() {
		stock = new LinkedList<Block>();
    }
	
	public boolean add(Block b) {
		return stock.add(b);
	}
	
	public void add(int nbBlocks, Block b) {
		for(int i=0;i<nbBlocks;i++) {
			stock.add(b);
		}
	}
	
	public void remove() {
		 stock.poll();
	}
	
	public void remove(int nbBlocks) {
		for(int i=0;i<nbBlocks;i++) {
			stock.poll();
		}
	}
	
	public int size() {
		return stock.size();
	}
}
