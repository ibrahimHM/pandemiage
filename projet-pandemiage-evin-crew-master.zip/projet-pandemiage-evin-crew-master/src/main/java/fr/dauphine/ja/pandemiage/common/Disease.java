package fr.dauphine.ja.pandemiage.common;

/**
 * Enum representing all diseases used in the game
 *
 */

public enum Disease {
	BLUE,
	YELLOW,
	BLACK,
	RED
}
