package fr.dauphine.ja.fhmbb.pandemiage.gameset;

import java.util.LinkedList;
import java.util.List;

import fr.dauphine.ja.pandemiage.common.Disease;
import fr.dauphine.ja.pandemiage.common.PlayerCardInterface;
import fr.dauphine.ja.pandemiage.common.PlayerInterface;
import fr.dauphine.ja.pandemiage.common.UnauthorizedActionException;

public class Player implements PlayerInterface {
	
	private String name;
	private City playerLocationCity;
	private String playerLocation;
	private List<PlayerCardInterface> playerHand = new LinkedList<PlayerCardInterface>();
	private boolean isAi;
	private Board b;

	
	public Player(String name, Board b, boolean isAi) {
		this.name = name;
		this.playerLocation = "Atlanta";
		this.b= b;
		this.setAi(isAi);
		
	}
	
	// BASIC ACTIONS
	
	@Override
	public void moveTo(String cityName) throws UnauthorizedActionException {
		this.playerLocationCity = b.getCityByName(playerLocation);
		
		boolean exist =false;
		for(City c : playerLocationCity.getNeighbors()) {
			if(c.getCityName().equals(cityName)) { //test if cityname is neighbour
				exist = true;
				this.playerLocation = cityName; // cityname is the new player location
				System.out.println(this.name+" move to "+cityName);
			}
		}
		if(!exist) {
			throw new UnauthorizedActionException("not neighbour"); 
		}
		
	}

	@Override
	public void flyTo(String cityName) throws UnauthorizedActionException {
		PlayerCard pc = null;
		for(PlayerCardInterface c : playerHand) {	//test if cityname in playerhand
			if(c.getCityName().equals(cityName)) { 
				pc = (PlayerCard) c;
				this.playerLocation = cityName;
				System.out.println(this.name+" fly to "+cityName);
			}
		}
		if(pc != null) {
			discardCardFromHand(pc);
		} else {
			throw new UnauthorizedActionException("flyTo not allowed to "+cityName);
		}
		
	}

	@Override
	public void flyToCharter(String cityName) throws UnauthorizedActionException {
		PlayerCard pc = null;
		for(PlayerCardInterface c : playerHand) {	//test if playerLocation in playerhand
			if(c.getCityName().equals(playerLocation)) {
				pc = (PlayerCard) c;
				this.playerLocation = cityName;
				System.out.println(this.name+" fly to charter "+cityName);
			}
		}
		if(pc != null) {
			discardCardFromHand(pc);
		} else {
			throw new UnauthorizedActionException("flyToCharter not allowed to "+cityName);
		}
		
	}

	@Override
	public void skipTurn() {
		// we do nothing and wait the next turn
		
	}

	// SPECIAL ACTIONS
	
	@Override
	public void treatDisease(Disease d) throws UnauthorizedActionException {
		
		City playerCity = b.getCityByName(playerLocation);
		
		if(playerCity.getInfectionLevel(d) == 0) { //if player location already cured
			throw new UnauthorizedActionException("Disease "+d+" already cured in "+playerLocation);
		}else {
			if(b.getCureMarker().get(d)) {
				// we remove all of the block from the city of playerLocation
				// if this Disease is cured
				
				//we set 0 for the levelInfection because cured
				playerCity.setInfectionLevel(d, 0); 
				System.out.println(this.name+" : "+playerLocation+" is cured from "+d+" now");

			}else {
				// we remove one block from the city of playerLocation
				// if this Disease is not cured
				
				int infection = playerCity.getInfectionLevel(d);
				playerCity.setInfectionLevel(d, infection-1);
				System.out.println(this.name+" treat disease "+d+" in "+playerLocation);
				
				//then we put the block into the stock
				b.addToStock(d);
			}
		}
				
	}

	@Override
	public void discoverCure(List<PlayerCardInterface> cardNames) throws UnauthorizedActionException {
		if(cardNames.size() == 5) {		//cardNames have to be a list of five cards
			
			if(playerHand.containsAll(cardNames)) { 
				boolean allEqual = true;
				
				//
				for (PlayerCardInterface card : cardNames) { //compare diseases of the 5 cards, they have to be the same
					if(!card.getDisease().equals(cardNames.get(0).getDisease()))
				        allEqual = false;
				}
				
				if(allEqual) { // if same disease	
					System.out.println(this.name+" discover cure for "+cardNames.get(0).getDisease());
					b.setCureMarker(cardNames.get(0).getDisease(), true);
					playerHand.removeAll(cardNames);
				}else {
					throw new UnauthorizedActionException("Not same diseases");
				}
				
			}else {
				throw new UnauthorizedActionException("Cards given dont match with hand");
			}
		}else {
			throw new UnauthorizedActionException("We need a list of five cards");
		}
		
		
	}

	@Override
	public String playerLocation() {
		return playerLocation;
	}

	@Override
	public List<PlayerCardInterface> playerHand() {
		return playerHand;
	}

	public void setPlayerHand(List<PlayerCardInterface> playerHand) {
		this.playerHand = playerHand;
	}

    public void setPlayerLocation(String playerLocation) {
    		this.playerLocation = playerLocation;
    }

    public void discardCardFromHand(PlayerCard card) {
    		playerHand.remove(card);
    }
    
    public void addCardToHand(PlayerCard card) {
    		playerHand.add(card);
    }
    
    public int handSize() {
    		return playerHand.size();
    }
    
    public String getName() {
		return name;
	}
    
    public void setName(String name) {
		this.name = name;
	}
    
    public boolean isAi() {
		return isAi;
	}

	public void setAi(boolean isAi) {
		this.isAi = isAi;
	}

	@Override
    public String toString() {
		return name;
    	
    }

}
