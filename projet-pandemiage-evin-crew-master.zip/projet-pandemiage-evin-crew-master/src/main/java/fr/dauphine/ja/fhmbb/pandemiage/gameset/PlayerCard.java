package fr.dauphine.ja.fhmbb.pandemiage.gameset;

import fr.dauphine.ja.pandemiage.common.Disease;
import fr.dauphine.ja.pandemiage.common.PlayerCardInterface;

public class PlayerCard extends Card implements PlayerCardInterface{

	protected String cityName;
	protected Disease disease;
	
	public PlayerCard(String cityName, Disease disease) {
		this.cityName = cityName;
		this.disease = disease;
	}


	public PlayerCard() {
		// TODO Auto-generated constructor stub
	}


	@Override
	public String getCityName() {
		// TODO Auto-generated method stub
		return this.cityName;
	}

	@Override
	public Disease getDisease() {
		// TODO Auto-generated method stub
		return disease;
	}


	@Override
	public String toString() {
		return cityName + "-" + disease;
	}
	
	

}
