package fr.dauphine.ja.fhmbb.pandemiage.ai;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import fr.dauphine.ja.pandemiage.common.AiInterface;
import fr.dauphine.ja.pandemiage.common.Disease;
import fr.dauphine.ja.pandemiage.common.GameInterface;
import fr.dauphine.ja.pandemiage.common.PlayerCardInterface;
import fr.dauphine.ja.pandemiage.common.PlayerInterface;
import fr.dauphine.ja.pandemiage.common.UnauthorizedActionException;

public class StupidAi implements AiInterface {
	@Override
	public void playTurn(GameInterface g, PlayerInterface p) {
		for(int i=0;i<4;++i) { // we can do 4 actions in one turn
			try {
								
				String cityName;
				
				int actionChoice = new Random().nextInt(6)+1;
				
				// we choose randomly an action
				switch(actionChoice) {
				
					case 1:		//MOVE TO
						
						//recuperation of actually list of neighbour
						List<String> neighbours = g.neighbours(p.playerLocation());
						
						// we choose a random neighbour
						int neighbourChoice = new Random().nextInt(neighbours.size());
						
						p.moveTo(neighbours.get(neighbourChoice));
						break;
						
					case 2:		//FLY TO
						
						//recuperation of the card list of player hand
						List<PlayerCardInterface> playerHand = p.playerHand();						
						
						int playerHandChoice = new Random().nextInt(playerHand.size());
						
						// we choose a random city given in playerhand
						cityName = playerHand.get(playerHandChoice).getCityName();
						p.flyTo(cityName);						
						break;
						
					case 3:		//FLY TO CHARTER
						
						// we choose a random city in the game
						int cityChoice = new Random().nextInt(g.allCityNames().size());
						cityName = g.allCityNames().get(cityChoice);
						
						boolean inPlayerHand = false;
						
						for(PlayerCardInterface c : p.playerHand()) {	//test if playerLocation in playerhand
							if(c.getCityName().equals(p.playerLocation())) {
								inPlayerHand = true;
							}								
						}
						
						if(inPlayerHand) { // playerLocation is in playerhand
							p.flyToCharter(cityName);
						}else{
							i--; // we can't do this action so decrement i to try another action
						}
						break;
						
					case 4:		//SKIP TURN
						
						p.skipTurn();
						i=4; //skip turn and don't do next actions
						break;		
						
					case 5:		//DISCOVER CURE
												
						if(p.playerHand().size()>=5) {
							//we take the 5 firsts cards of player hand
							List<PlayerCardInterface> cardNames = p.playerHand().subList(0, 5);							
							boolean allEqual = true;
							
							for (PlayerCardInterface card : cardNames) {
								if(!card.getDisease().equals(cardNames.get(0).getDisease())) //test if both cards have same disease
							        allEqual = false;
							}
							
							if(allEqual) {			// if same disease				
								p.discoverCure(cardNames);
							}else {
								i--; // we can't do this action so decrement i to try another action
							}
							
						}else {
							i--; // we can't do this action, playerhand size < 5
						}
						break;					
								
					case 6:		//TREAT DISEASE
						
						Disease d = Disease.values()[new Random().nextInt(4)]; //we choose a random disease
						
						if(g.infectionLevel(p.playerLocation(), d) != 0) { // if player location is infected
							p.treatDisease(d);
						}else {
							i--; // we don't do this action, player location is not infected 
						}
						
						break;			
				}
						
				
			} catch (UnauthorizedActionException e) {
				e.printStackTrace();
			}
		}
	} 
	

	@Override
	public List<PlayerCardInterface> discard(GameInterface g, PlayerInterface p, int maxHandSize, int nbEpidemic){
		List<PlayerCardInterface> discard = new ArrayList<>();
		int numdiscard = p.playerHand().size() - maxHandSize;  

		for(int i = 0; i < numdiscard; i++)
			discard.add(p.playerHand().get(i)); 

		return discard;
	}
}

