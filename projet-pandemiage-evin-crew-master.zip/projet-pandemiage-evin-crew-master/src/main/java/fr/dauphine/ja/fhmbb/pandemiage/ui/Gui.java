package fr.dauphine.ja.fhmbb.pandemiage.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import com.sun.javafx.geom.Rectangle;

import fr.dauphine.ja.fhmbb.pandemiage.gameengine.GameEngine;
import fr.dauphine.ja.fhmbb.pandemiage.gameset.Board;
import fr.dauphine.ja.fhmbb.pandemiage.gameset.City;
import fr.dauphine.ja.fhmbb.pandemiage.gameset.Player;
import fr.dauphine.ja.fhmbb.pandemiage.gameset.PlayerCard;
import fr.dauphine.ja.pandemiage.common.Disease;
import fr.dauphine.ja.pandemiage.common.PlayerCardInterface;
import fr.dauphine.ja.pandemiage.common.UnauthorizedActionException;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class Gui extends Application {
	public static final String DEFAULT_AIJAR = "./target/pandemiage-1.0-SNAPSHOT-ai.jar"; 
	public static final String DEFAULT_CITYGRAPH_FILE = "./pandemic.graphml";
	public static final int DEFAULT_TURN_DURATION = 1;	//in seconds
	public static final int DEFAULT_DIFFICULTY = 0; // Normal
	public static final int DEFAULT_HAND_SIZE = 9;
	
	public static final int NUMBER_OF_PLAYERS = 0;
	public static final int NUMBER_OF_IAPLAYERS = 2;
	 
	Task<Board> task;
	public static void main(String[] args) {
		String aijar = DEFAULT_AIJAR; 
		String cityGraphFile = DEFAULT_CITYGRAPH_FILE; 
		int difficulty = DEFAULT_DIFFICULTY; 
		int turnDuration = DEFAULT_TURN_DURATION;
		int handSize = DEFAULT_HAND_SIZE;
		int nbPlayers = NUMBER_OF_PLAYERS;
		int nbIAPlayers = NUMBER_OF_IAPLAYERS;
		
		Options options = new Options();
		CommandLineParser parser = new DefaultParser();

		options.addOption("a", "aijar", true, "use <FILE> as player Ai.");
		options.addOption("d", "difficulty", true, "Difficulty level. 0 (Introduction), 1 (Normal) or 3 (Heroic).");
		options.addOption("c", "citygraph", true, "City graph filename.");
		options.addOption("t", "turnduration", true, "Number of seconds allowed to play a turn.");
		options.addOption("s", "handsize", true, "Maximum size of a player hand.");
		options.addOption("h", "help", false, "Display this help");
		options.addOption("p", true, "Number of players");
		options.addOption("i", true, "Number of ia players");
		
		try {
			CommandLine cmd = parser.parse( options, args);
			
			if(cmd.hasOption("a")) {
				aijar = cmd.getOptionValue("a");				
			}
			
			if(cmd.hasOption("c")) {
				cityGraphFile = cmd.getOptionValue("c");
			}

			if(cmd.hasOption("d")) {
				difficulty = Integer.parseInt(cmd.getOptionValue("d"));
			}
			
			if(cmd.hasOption("t")) {
				turnDuration = Integer.parseInt(cmd.getOptionValue("t"));
			}
			if(cmd.hasOption("s")) {
				handSize = Integer.parseInt(cmd.getOptionValue("s"));
			}
			
			if(cmd.hasOption("p")) {
				nbPlayers = Integer.parseInt(cmd.getOptionValue("p"));
			}
			
			if(cmd.hasOption("i")) {
				nbIAPlayers = Integer.parseInt(cmd.getOptionValue("i"));
			}

			/* ... */ 
			
			if(cmd.hasOption("h")) {
				HelpFormatter formatter = new HelpFormatter();
				formatter.printHelp( "pandemiage", options );
				System.exit(0);
			}			
			
		} catch (ParseException e) {
			System.err.println("Error: invalid command line format.");
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp( "pandemiage", options );
			System.exit(1);
	    }
		
		/**
		Board b = new Board();
		GameEngine g = new GameEngine(cityGraphFile, aijar, handSize, difficulty, nbPlayers,nbIAPlayers, b);
		b.setG(g);
		**/
		//g.loop();
		launch(args);
		
	      
    }

	@Override
	public void start(Stage stage) throws Exception {
		stage.setTitle("Pandemiage");
		
		
		
        Button btn = new Button("OK");
        btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
            		
          
            }
    
        
      
        	 });
         
        
        String aijar = DEFAULT_AIJAR; 
		String cityGraphFile = DEFAULT_CITYGRAPH_FILE; 
		int difficulty = DEFAULT_DIFFICULTY; 
		int turnDuration = DEFAULT_TURN_DURATION;
		int handSize = DEFAULT_HAND_SIZE;
		int nbPlayers = NUMBER_OF_PLAYERS;
		int nbIAPlayers = NUMBER_OF_IAPLAYERS;
		
		//on récupère le gameEngine et le board
		Board b = new Board();
		GameEngine g = new GameEngine(cityGraphFile, aijar, handSize, difficulty,turnDuration, nbPlayers,nbIAPlayers, b);
		b.setG(g);
		
		
		
		
		
		Thread th= new Thread() {
			
			public void run(){
				while(true) {
					
				}
			}
			
		};	
  		th.start();
  		
		
		StackPane p = new StackPane(); 
		
		/**
		 * BackGround
		 */
		Image image=  new Image(getClass().getResource("map.png").toString());;
		Background bgImg = new Background(new BackgroundImage(image,BackgroundRepeat.NO_REPEAT,BackgroundRepeat.NO_REPEAT,BackgroundPosition.CENTER,BackgroundSize.DEFAULT));
 	    p.setBackground(bgImg);
  		
 	    /**
 	     * recupèrer les villes 
 	     */
 	   Map<String,City> cities = b.getAllCities();
 	   
 	   /**
 	    * recupèrer le max des corrdonnées des villes
 	    * 
 	    */
 	   List<Float> list_x= new ArrayList<Float>();
	   List<Float> list_y= new ArrayList<Float>();
	   
	   for (Map.Entry<String, City> entry : cities.entrySet()) {
			City city = entry.getValue();
			list_x.add(city.getX());
			list_y.add(city.getY());
	    }
	   Float max_x = Collections.max(list_x);
	   Float max_y =Collections.max(list_y);
	   
		/**
		 * recupèrer les voisins de chaque ville
		 */
	   BorderPane borderPane=  new BorderPane();
	   for (Map.Entry<String, City> entry : cities.entrySet()) {
			
			City city = entry.getValue();
			List<City> neighbours=city.getNeighbors();
			Float x=normaliseX(city.getX(),max_x);
			Float y= normaliseY(city.getY(),max_y);;
			 
			Circle circle= new Circle(x,y,10.0,Color.rgb(city.getR(), city.getG(), city.getB()));
		
			
			borderPane.getChildren().add(circle);
			for(City c:neighbours) {
				Float xn=normaliseX(c.getX(),max_x);
				Float yn=normaliseY(c.getY(),max_y);
				Line line= new Line(x,y,xn,yn);
			
					line.setStroke(Color.rgb(city.getR(), city.getG(), city.getB()));
				
				
				borderPane.getChildren().add(line);
			}
			
			
		}
	   
	    //une liste de noeuds 
		List<Node> list_nodes=new ArrayList<Node>();
		
			HBox hbox = new HBox();
	        hbox.setAlignment(Pos.TOP_RIGHT);
	       
	        
	        Image cube_rouge=  new Image(getClass().getResource("cube_red.png").toString());
	        ImageView mv = new ImageView(cube_rouge);
	        mv.setFitHeight(25);
	        mv.setFitWidth(25);
	        //un compteur pour le nombre de cubes rouges
	        VBox vbox_rouge= new VBox();
	        String str="";
	        str+=b.getG().getNbBlocks(Disease.RED);
	        Label cpt_Rouge=new Label(str);
	        cpt_Rouge.setTextFill(Color.rgb(180, 50, 50));
	        vbox_rouge.setSpacing(5);
	        vbox_rouge.getChildren().addAll(mv,cpt_Rouge);
	        list_nodes.add(vbox_rouge);
	       
	        //un compteur pour le nombre de cubes verts
	        Image cube_green=  new Image(getClass().getResource("cube_blue.png").toString());
	         ImageView mv_green = new ImageView(cube_green);
	         mv_green.setFitHeight(25);
	         mv_green.setFitWidth(25);
	         String str1="";
		     str1+=g.getNbBlocks(Disease.BLUE);
		        
	         VBox vbox_Green= new VBox();
	         Label cpt_Green=new Label(str1);
	         cpt_Green.setTextFill(Color.rgb(50, 50, 180));
	         vbox_Green.setSpacing(5);
	         vbox_Green.getChildren().addAll(mv_green,cpt_Green);
	         list_nodes.add(vbox_Green);
		     
	        
		     //un compteur pour le nombre de cubes jaune
		        Image cube_yellow=  new Image(getClass().getResource("cube_yellow.png").toString());
		        ImageView mv_yellow = new ImageView(cube_yellow);
		        mv_yellow.setFitHeight(25);
		        mv_yellow.setFitWidth(25);
		        VBox vbox_Yellow= new VBox();
		        String str2="";
			     str2+=b.getG().getNbBlocks(Disease.YELLOW);
		        Label cpt_Yellow=new Label(str2);
		        cpt_Yellow.setTextFill(Color.rgb(255, 255, 0));
		        vbox_Yellow.setSpacing(5);
		        vbox_Yellow.getChildren().addAll(mv_yellow,cpt_Yellow);
		        list_nodes.add(vbox_Yellow);
		        
		        
		        //un compteur pour le nombre de cubes noires
		        
		        Image cube_black=  new Image(getClass().getResource("cube_black.png").toString());
		        ImageView mv_black = new ImageView(cube_black);
		        mv_black.setFitHeight(25);
		        mv_black.setFitWidth(25);
		        VBox vbox_Black= new VBox();
		        String str3 = "";
			    str3 += b.getG().getNbBlocks(Disease.BLACK);
		        Label cpt_black=new Label(str3);
		        
		        cpt_black.setTextFill(Color.rgb(255,255,255));
		        vbox_Black.setSpacing(5);
		        vbox_Black.getChildren().addAll(mv_black,cpt_black);
		        list_nodes.add(vbox_Black);
		        
		        
		       
		        //représenter chaqu'une des maladies
		        
		        Image disease_blue=  new Image(getClass().getResource("disease_large_blue.png").toString());
		         ImageView disease_b = new ImageView(disease_blue);
		         disease_b.setFitHeight(30);
		         disease_b.setFitWidth(30);
		         list_nodes.add(disease_b );
		         
		         Image disease_red=  new Image(getClass().getResource("disease_large_red.png").toString());
		         ImageView disease_r = new ImageView(disease_red);
		         disease_r.setFitHeight(30);
		         disease_r.setFitWidth(30);
		         list_nodes.add(disease_r);
		         
		         Image disease_black=  new Image(getClass().getResource("disease_large_black.png").toString());
		         ImageView disease_bk = new ImageView(disease_black);
		         disease_bk.setFitHeight(30);
		         disease_bk.setFitWidth(30);
		         list_nodes.add(disease_bk);
		         
		         Image disease_yellow=  new Image(getClass().getResource("disease_large_yellow.png").toString());
		         ImageView disease_y = new ImageView(disease_yellow);
		         disease_y.setFitHeight(30);
		         disease_y.setFitWidth(30);
		         list_nodes.add(disease_y);
		         
		         
		       //infection rate
		         Image infection_rate=  new Image(getClass().getResource("infection_rate.png").toString());
		         ImageView mv_infection_rate = new ImageView(infection_rate);
		         mv_infection_rate.setFitHeight(25);
		         mv_infection_rate.setFitWidth(25);
		         VBox vbox_infection_rate= new VBox();
		         String s="";
		         s+=b.getInfectionRate();
		         Label cpt_infection_rate=new Label(s);
		         cpt_infection_rate.setTextFill(Color.rgb(50, 180, 50));
		         vbox_infection_rate.setSpacing(5);
		         vbox_infection_rate.getChildren().addAll(mv_infection_rate,cpt_infection_rate);
		         list_nodes.add(vbox_infection_rate);
		         
		         
		         
       //Récupérer les joueurs 
	    List<Player> players= g.getPlayers();
		Player current_player=players.get(b.getCurrentPlayerId());		
	 
				        		
	    String location= current_player.playerLocation();
	    
	    //Initialisation de la fenetre 
	    Stage fenetre= new Stage();
	    HBox hb= new HBox();
	    
	   
	  	
	  	
	    Button MoveTo= new Button("MoveTo");
	    Button FlyTo= new Button("FlyTo");
	    Button discoverCure= new Button("discoverCure");
	    Button treatDisease= new Button("treatDisease"); 
	    Button flyToCharter= new Button("flyToCharter");
	    Button skipTurn= new Button("skipTurn");
	    hb.getChildren().addAll(MoveTo,FlyTo,discoverCure,treatDisease,flyToCharter,skipTurn);
	    City P_city=cities.get(location);
	    List<City> neighbors = P_city.getNeighbors();
	    List<Button> buttons_voisins= new ArrayList<Button>();
	    
	    for(City c:neighbors) {
	    		btn = new Button(c.getCityName());
	    		btn.setOnAction(e->{ try {
					current_player.moveTo(c.getCityName());
				} catch (UnauthorizedActionException e1) {
					
					e1.printStackTrace();
				}});
	    		buttons_voisins.add(btn);
	    		
	    }
	    List<Button> Btn_toFly=new ArrayList<Button>();
	    //Définit un titre pour notre fenêtre
	    		List<City> ableToFly = new ArrayList<>();
	  	    for(PlayerCardInterface card: current_player.playerHand()) {
	  	    		ableToFly.add(cities.get(card.getCityName()));
	  	    		Button toFly =new Button(card.getCityName());
	  	    		toFly.setOnAction(e->{ try {
						current_player.flyTo(card.getCityName());
					} catch (UnauthorizedActionException e1) {
						
						e1.printStackTrace();
					}});
		    		Btn_toFly.add(toFly);
	  		
	  	    }
	  	VBox TOF = new VBox();
	  	TOF.getChildren().addAll(Btn_toFly);
	  	FlyTo.setOnAction(e->{Stage stg=new Stage();
	    stg.setScene(new Scene(TOF,70,200));
	    stg.show();});
	  	 
	  	
	    VBox vbvoisins= new VBox();
	    vbvoisins.getChildren().addAll(buttons_voisins);
	   
	    MoveTo.setOnAction(e->{Stage stg=new Stage();
	    stg.setScene(new Scene(vbvoisins,70,200));
	    stg.show();});
	    
	    
	    
	    
	    
	  	Scene scene2= new Scene(hb,500,80);
	  	
	  	//on positionne le joueur courant sur la carte
	  	
	  	
	  	float x_city=P_city.getX();
	  	float y_city=P_city.getY();
	  	
	  	Float Xl=normaliseX(x_city, max_x);
		Float Yl=normaliseY(y_city, max_y);
		Random gen= new Random();
		Circle circle= new Circle(Xl,Yl,20,Color.rgb(gen.nextInt(255),gen.nextInt(255),gen.nextInt(255)));
		borderPane.getChildren().add(circle);
		
		
      
	   	p.getChildren().add(borderPane);
	   	hbox.getChildren().addAll(list_nodes);    
        p.getChildren().addAll(hbox);
        Scene scene = new Scene(p, 1200, 1000);        
        stage.setScene(scene);
        stage.show();
        fenetre.setScene(scene2);
        fenetre.setTitle("Current_player");
        fenetre.show();
		
	}
	

	/**
     * normaliser les valeurs de x
     * @param x
     * @param max
     * @return
     */
    public Float normaliseX(Float x, Float max) {
    	      return (float) (((x+max)/2.0)+10.0);
    	
    	
    }
    /**
     * normaliser les valeurs de y
     * @param y
     * @param max
     * @return
     */
    public Float normaliseY(Float y, Float max) {
		
		return (float) (((max-y)/2.0)+140.0);
    	
    	
    }
	
	}


	



           