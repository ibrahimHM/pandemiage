package fr.dauphine.ja.fhmbb.pandemiage.human;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import fr.dauphine.ja.fhmbb.pandemiage.gameengine.GameEngine;
import fr.dauphine.ja.fhmbb.pandemiage.gameset.Player;
import fr.dauphine.ja.fhmbb.pandemiage.gameset.PlayerCard;
import fr.dauphine.ja.pandemiage.common.AiInterface;
import fr.dauphine.ja.pandemiage.common.Disease;
import fr.dauphine.ja.pandemiage.common.GameInterface;
import fr.dauphine.ja.pandemiage.common.PlayerCardInterface;
import fr.dauphine.ja.pandemiage.common.PlayerInterface;
import fr.dauphine.ja.pandemiage.common.UnauthorizedActionException;

public class HumanPlayer implements  AiInterface{
	

	private void displayInfectionLevel(GameInterface g, PlayerInterface p) {
		int cpt=0;
		for(Disease d : Disease.values()) {
			cpt++;
			System.out.println(cpt + " - " + d + " : " + g.infectionLevel(p.playerLocation(), d));
		}
	}
	
	@Override
	public void playTurn(GameInterface g, PlayerInterface p) {
		boolean skipturn = false;
		for(int i = 0; i<4; i++) {
			if(skipturn==true) {
				break;
			}
			System.out.println("now in " + p.playerLocation());
			System.out.println("Hand : " + p.playerHand());
			displayInfectionLevel(g,p);
			
			System.out.println("\nPlay action " + (i +1) + " on 4 (1-move to, 2-flyto, 3-flytocharter, 4-skipturn, 5-treat disease, 6-discover cure)");
		
			System.out.println("Choisir une action :");
			Scanner sc = new Scanner(System.in);
			int action = sc.nextInt();
			switch(action) {
			case 1:
				try {
					
					System.out.println("Move to " + g.neighbours(p.playerLocation()));
					Scanner s = new Scanner(System.in);
					String dest = s.nextLine();
					p.moveTo(dest);
					
				} catch (UnauthorizedActionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 2:
				try {
					System.out.println("Fly To action");
					System.out.println("Where do you want to fly ?");
					Scanner sc2 = new Scanner(System.in);
					String dest = sc2.nextLine();
					p.flyTo(dest);
				} catch (UnauthorizedActionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 3:
				try {
					System.out.println("Fly To Charter");
					System.out.println("Where do you want to fly ?");
					Scanner sc4 = new Scanner(System.in);
					String dest = sc4.nextLine();
					p.flyToCharter(dest);
				} catch (UnauthorizedActionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 4:
				System.out.println("Skip turn");
				p.skipTurn();
				skipturn = true;
				break;
			
			case 5:
				try {
					
					System.out.println("Treat  Disease in " + p.playerLocation());
					
					System.out.println("Select one disease to cure (1,2,3,4)");
					Scanner sc2 = new Scanner(System.in);
					int d = sc2.nextInt();
					switch(d) {
						case 1:
							p.treatDisease(Disease.BLUE);
							break;
						case 2:
							p.treatDisease(Disease.YELLOW);
							break;
						case 3:
							p.treatDisease(Disease.BLACK);
							break;
						default:
							p.treatDisease(Disease.RED);
							
					}
					displayInfectionLevel(g,p);
					
				} catch (UnauthorizedActionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 6:
				try {
					List<PlayerCardInterface> list = new ArrayList<PlayerCardInterface>();
					System.out.println("You are about to discover a cure");
					
					System.out.println("Select 5 cards");
					
					for(int j=0;j<5;j++) {
						
						//sc3.close();
						PlayerCardInterface c = null;
						while(c == null) {
							Scanner sc3 = new Scanner(System.in);
							String cityName = sc3.nextLine();
							for(PlayerCardInterface cardfromhand : p.playerHand()) {
								if(cityName.equals(cardfromhand.getCityName())) {
									c = cardfromhand;
									list.add(c);
								}
								
							}
							if(c == null)
								System.out.println("No card in hand match with " + cityName);
								
						}
						
						
					}
					p.discoverCure(list);
					
										
				} catch (UnauthorizedActionException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			}
		}
	}
	
	@Override
	public List<PlayerCardInterface> discard(GameInterface g, PlayerInterface p, int maxHandSize, int nbEpidemic){
		List<PlayerCardInterface> discard = new ArrayList<>();
		int numdiscard = p.playerHand().size() - maxHandSize;  
		System.out.println("You have " + numdiscard + " card(s) to dicard from your hand. \n Actuel Hand : \n " + p.playerHand());
		
	
		for(int i = 1; i < numdiscard+1; i++) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the city name of the card " + i);
			String cityname = sc.nextLine();
			for(PlayerCardInterface card : p.playerHand() ) {
				if(card.getCityName().equals(cityname)) {System.out.println("trouve");
					discard.add(card);
				}
			}
		}
		return discard;

	}
	
}
